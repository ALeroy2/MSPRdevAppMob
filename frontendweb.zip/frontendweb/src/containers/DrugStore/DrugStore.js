import React from 'react';

export class DrugStore extends React.Component {
  render() {
    return (
      <div>

      </div>
    )
  }
}

export default DrugStore;
