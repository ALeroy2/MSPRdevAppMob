import React from 'react';

export class Form extends React.Component {
  render() {
    return (
      <div>
        Form
      </div>
    );
  }
}

export default Form;
