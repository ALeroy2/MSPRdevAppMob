import axios from 'axios';

const instance = axios.create({
  baseURL: 'http://172.16.60.6:80/'
});

export default instance;